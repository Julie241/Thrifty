package com.example.thrift

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Balance : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_balance)
    }
}