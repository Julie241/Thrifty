package com.example.thrift

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class HomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        val buttonOne: Button = findViewById(R.id.addFunds)
        buttonOne.setOnClickListener{
            val intent = Intent(this,Funds::class.java )
            startActivity(intent)
        }

        val buttonTwo: Button = findViewById(R.id.historyButtonOne)
        buttonTwo.setOnClickListener{
            val intent = Intent(this,History::class.java )
            startActivity(intent)
        }
        val buttonThree: Button = findViewById(R.id.spendingButton)
        buttonThree.setOnClickListener{
            val intent = Intent(this,Funds::class.java )
            startActivity(intent)
        }

        val buttonFour: Button = findViewById(R.id.balanceButtonOne)
        buttonFour.setOnClickListener{
            val intent = Intent(this,Balance::class.java )
            startActivity(intent)
        }
    }
}