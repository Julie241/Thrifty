package com.example.thrift

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

private lateinit var auth: FirebaseAuth

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = Firebase.auth

        val RegisterText: TextView = findViewById(R.id.SignUpText)
        RegisterText.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }

        val LoginButton: Button = findViewById(R.id.buttonLogin)
        LoginButton.setOnClickListener {
            performLogin()
        }
    }
        private fun performLogin() {
            val email: EditText = findViewById<EditText>(R.id.email_Login)
            val password: EditText = findViewById(R.id.password_Login)

            if (email.text.isEmpty() || password.text.isEmpty()) {
                Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT)
                    .show()
                return
            }
            val emailInput = email.text.toString()
            val passwordInput = password.text.toString()

            auth.signInWithEmailAndPassword(emailInput, passwordInput)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        val intent = Intent(this, dashboard::class.java)
                        startActivity(intent)

                    } else {
                        Toast.makeText(
                            baseContext, "Authentication failed.",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    }

                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error Occured ${it.localizedMessage}", Toast.LENGTH_SHORT)
                        .show()

                }

        }
    }

